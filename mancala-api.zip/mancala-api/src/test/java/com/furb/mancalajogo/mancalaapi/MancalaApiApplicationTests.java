package com.furb.mancalajogo.mancalaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MancalaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
