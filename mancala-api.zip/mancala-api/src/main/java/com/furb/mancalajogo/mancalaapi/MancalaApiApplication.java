package com.furb.mancalajogo.mancalaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MancalaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MancalaApiApplication.class, args);
	}

}
